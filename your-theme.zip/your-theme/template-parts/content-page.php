<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Your_Theme
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
	</header><!-- .entry-header -->

	<div class="entry-content">
		<?php
			the_content();

			wp_link_pages( array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'your-theme' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->

<!-- Calling About Section From Home Page -->
<?php echo get_field('about'); ?>

<?php
if(is_front_page()){
?>
	<h1>======================================= Calling Page In Another Page Start =======================================</h1>
	<?php
	// query for the about page
	$your_query = new WP_Query( 'page_id=23' );
	// "loop" through query (even though it's just one page)
	while ( $your_query->have_posts() ) : $your_query->the_post();
			the_content();
			the_post_thumbnail();
	endwhile;

	?>
	<h1>======================================= Calling Page In Another Page Over =======================================</h1>

	<?php
	// reset post data (important!)
	wp_reset_postdata();

}
?>



</article><!-- #post-## -->
