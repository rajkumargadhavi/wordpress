<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Your_Theme
 */



get_header(); ?>
<style>

.note{
	color: #ff0000;
}
</style>
<h2>==========================================Index.php Start==========================================</h2>
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

<h1 class="note">Note: Remove Post Note Style From Index Top</h1>

<h2>==========================================Slider Start==========================================</h2>
<!-- *************************************************************************
Slider
************************************************************************* -->
<!-- Section Intro Slider
================================================== -->
<div id="carousel-example-generic" class="carousel intro slide">
	<!-- Indicators -->
	<ol class="carousel-indicators">

		<?php

		$notun=new WP_Query(array(
			'post_type'=>'bcarousel'
		));

		$indiactor =-1;
		 while($notun-> have_posts()) : $notun->the_post(); $indiactor++?>

		<li data-target="#carousel-example-generic" data-slide-to="<?php echo $indiactor; ?>" <?php if($indiactor==0): ?> class="active"  <?php endif; ?>></li>

 <?php endwhile; ?>

	</ol>
	<!-- Wrapper for slides -->
	<div class="carousel-inner" role="listbox">


<?php
$carousel = new WP_Query(array(
	'post_type' =>'bcarousel',
));

		$korim=0;

		while($carousel-> have_posts()) : $carousel->the_post();


// IF USED THE IMG TAG THAN REMOVE THIS ARRAY CODE

// $thumb_id = get_post_thumbnail_id();
// $thumb_url_array = wp_get_attachment_image_src($thumb_id, 'thumbnail-size', true);
// $thumb_url = $thumb_url_array[0];


		$thumb_id = get_post_thumbnail_id();
		$thumb_url_array = wp_get_attachment_image_src($thumb_id, 'thumbnail-size', true);
		$thumb_url = $thumb_url_array[0];

		$korim++
		 ?>
		 <?php if($korim==1):?>
		<div class="item active" style="background-image:url('<?php echo $thumb_url ?>')">


 <!-- IF USED THE IMG TAG THAN SET THIS ITEM TAG  -->
	<!-- <div class="item active"> -->

		<?php else: ?>
				<div class="item" style="background-image:url('<?php echo $thumb_url ?>')">
		 <?php endif; ?>




		<!--IF WE USE IMAGE TAG THAN USE THIS CODE  -->

		<!-- <div class="slider_image">
			<?php the_post_thumbnail(); ?>
		</div> -->
			<div class="carousel-caption">
				<h2 data-animation="animated bounceInDown"><?php the_title(); ?></h2>
				<h1 data-animation="animated bounceInUp"><?php the_content(); ?></h1>
				<a href="#" class="btn btn-ghost btn-lg" data-animation="animated fadeInLeft">Start Tour</a>
				<a href="#" class="btn btn-primary btn-lg" data-animation="animated fadeInRight">Learn More</a>
			</div>
		</div>
		<!-- /.item -->

<?php endwhile; ?>

	</div>
	<!-- /.carousel-inner -->
	<!-- Controls (currently displayed none from style.css)-->
	<a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
	<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
	<span class="sr-only">Previous</span>
	</a>
	<a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
	<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
	<span class="sr-only">Next</span>
	</a>
</div>
<!-- /.carousel -->

<h2>==========================================Slider End==========================================</h2>


<!-- *************************************************************************
 Calling Counter
************************************************************************* -->
<h1 class="note">Counter Start</h1>
			<?php
							echo '<h1>'.get_option('counter1').'</h1>';

							echo '<h1>'.get_option('counter2').'</h1>';

							echo '<h1>'.get_option('counter3').'</h1>';

							echo '<h1>'.get_option('counter4').'</h1>';
			?>
<!-- ************************************************************************* -->


<!-- *************************************************************************
Social Url  Call
************************************************************************* -->
<h1 class="note">Social Urls</h1>
			<?php
			if(get_option('facebook_url')!=='')
			{
				echo '<h1> this is the fb url '.get_option('facebook_url').'</h1>';
			}

			?>
<!-- ************************************************************************* -->



<!-- *************************************************************************
Copyright Text Call
************************************************************************* -->
<h1 class="note">Copyright Text Start</h1>
			<?php
							echo '<h1>'.get_option('copyright').'</h1>';
			?>
<!-- ************************************************************************* -->

		<?php
		if ( have_posts() ) :

			if ( is_home() && ! is_front_page() ) : ?>
				<header>
					<h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
				</header>



			<?php
			endif;

			/* Start the Loop */
			while ( have_posts() ) : the_post();
?>
<!-- Post Title With Link -->
<h1><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h1>
<span class="entry-date">Post Date:<?php echo get_the_date(); ?></span>
<br />
<br />
<!-- post thumbnail  -->
<?php  $myimage = wp_get_attachment_image_src(get_post_thumbnail_id(), 'full');?>
<img src="<?php echo $myimage[0];?>" height="300px" width="30%" >



<!-- Post Content With Fix Length And Read More Button -->
				<?php the_excerpt();?>
				 <a href="<?php the_permalink(); ?>" title="Read More">Read More</a>
<BR/>
<BR/>




<?php
			endwhile;

			//  Paginations Sart

				 echo paginate_links();

				// If we wants older posts  New post thn uncommnet this below code
				// echo the_posts_navigation();

			//  Paginations End

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif; ?>

		</main><!-- #main -->
	</div><!-- #primary -->






<?php

get_footer();
