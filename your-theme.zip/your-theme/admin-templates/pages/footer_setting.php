<h1>Footer Settings</h1>
<?php settings_errors();?>
<form action="options.php" method="post">

<?php

    settings_fields('footer-option-group');
    do_settings_sections('footer-theme-settings');
    submit_button('Save');
?>

</form>
