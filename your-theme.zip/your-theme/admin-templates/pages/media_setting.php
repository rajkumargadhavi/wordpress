<h1>Media Settings</h1>
<?php settings_errors();?>
<?php
  $media1=esc_attr(get_option('media1'));
?>
<div>
  <div>
    <img id="media1-preview" src="<?php echo esc_attr(get_option('media1')); ?>" height="150px"/>

  </div>
</div>
<form action="options.php" method="post">
<?php
    settings_fields('media-option-group');
    do_settings_sections('media-theme-settings');
    submit_button('Save');
?>

</form>
