<h1>Homepage Settings</h1>

<?php settings_errors();?>
<form action="options.php" method="post">

<?php

    settings_fields('homepage-option-group');
    do_settings_sections('homepage-theme-settings');
    submit_button('Save');
?>

</form>
