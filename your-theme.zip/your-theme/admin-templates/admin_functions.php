<?php

// include media js file in admin page
function yourtheme_load_admin_scripts( $hook ){
  // adding JQuery File
  wp_register_script('jquery-script',get_template_directory_uri().'/js/jquery-3.2.1.min.js',array('jquery'),'1.0.0',true);

  // adding Media JS File
  wp_enqueue_media();
  wp_register_script('media-upload-script',get_template_directory_uri().'/js/mediaupload.js',array('jquery'),'1.0.0',true);
  wp_enqueue_script('media-upload-script');
}
add_action('admin_enqueue_scripts','yourtheme_load_admin_scripts');


// add pages and sub pages
function theme_admin_page(){
  add_menu_page('Theme Options','Customize','manage-options','official-theme-settings','theme_init','dashicons-menu',5);

  add_submenu_page('official-theme-settings','General Settings','General','manage_options','general-theme-settings','theme_general_settings');
  add_submenu_page('official-theme-settings','Homepage Settings','Homepage','manage_options','homepage-theme-settings','theme_homepage_settings');
  add_submenu_page('official-theme-settings','Header Settings','Header','manage_options','header-theme-settings','theme_header_settings');
  add_submenu_page('official-theme-settings','Footer Settings','Footer','manage_options','footer-theme-settings','theme_footer_settings');
  add_submenu_page('official-theme-settings','Media  Settings','Media','manage_options','media-theme-settings','theme_media_settings');

}

function theme_settings(){

  // SOCIAL ICONS FOR GENERAL SETTINGS
  register_setting('general-option-group','facebook_url');
  add_settings_section('theme-index-options','General Settings','theme_general_options','general-theme-settings');
  add_settings_field('facebook_url_text','Facebook Url','facebook_url_callback','general-theme-settings','theme-index-options');


  // Counter Start FOR HOME PAGE
    add_settings_section('theme-index-options','Homepage Settings','theme_homepage_options','homepage-theme-settings');

  register_setting('homepage-option-group','counter1');
  add_settings_field('count1_text','Counter 1 Text','count1_callback','homepage-theme-settings','theme-index-options');

  register_setting('homepage-option-group','counter2');
  add_settings_field('count2_text','Counter 2 Text','count2_callback','homepage-theme-settings','theme-index-options');

  register_setting('homepage-option-group','counter3');
  add_settings_field('count3_text','Counter 3 Text','count3_callback','homepage-theme-settings','theme-index-options');


  register_setting('homepage-option-group','counter4');
  add_settings_field('count4_text','Counter 4 Text','count4_callback','homepage-theme-settings','theme-index-options');

// FOOTER COPYRIGHT TEXT

register_setting('footer-option-group','copyright');
add_settings_section('theme-index-options','Footer Settings','theme_footer_options','footer-theme-settings');
add_settings_field('copyright','Copyright Text','copyright_callback','footer-theme-settings','theme-index-options');


// MEDIA TEXT

register_setting('media-option-group','media1');
add_settings_section('theme-index-options','Media Settings','theme_media_options','media-theme-settings');
add_settings_field('media1','Media One','media1_callback','media-theme-settings','theme-index-options');

}

// ADD ACTIONS
add_action('admin_menu','theme_admin_page');
add_action('admin_init','theme_settings');


// THEME SETTING SUB MENU CALLBACKS
function theme_general_settings(){
  require_once(get_template_directory().'/admin-templates/pages/general_setting.php');
}

function theme_homepage_settings(){
  require_once(get_template_directory().'/admin-templates/pages/homepage_setting.php');
}
function theme_header_settings(){
  require_once(get_template_directory().'/admin-templates/pages/header_setting.php');
}
function theme_footer_settings(){
  require_once(get_template_directory().'/admin-templates/pages/footer_setting.php');
}
function theme_media_settings(){
  require_once(get_template_directory().'/admin-templates/pages/media_setting.php');
}


function theme_homepage_options(){
  echo'Customize Hompage Settings';
}

function theme_general_options(){
  echo'Customize General Settings';
}
function theme_header_options(){
  echo'Customize Header Settings';
}
function theme_footer_options(){
  echo'Customize Footer Settings';
}
function theme_media_options(){
  echo'Customize Media Settings';
}

// General page Social callbacks

function facebook_url_callback(){
  $preText = get_option('facebook_url');
echo'<input type="text" name="facebook_url" placeholder="Facebook Url" value="'.$preText.'" />';
}


// Counter callbacks
function count1_callback(){
  $preText = get_option('counter1');
echo'<input type="text" name="counter1" placeholder="First Counter Value" value="'.$preText.'" />';
}

function count2_callback(){
  $preText = get_option('counter2');
echo'<input type="text" name="counter2" placeholder="Second Counter Value" value="'.$preText.'" />';
}

function count3_callback(){
  $preText = get_option('counter3');
echo'<input type="text" name="counter3" placeholder="Third Counter Value" value="'.$preText.'" />';
}

function count4_callback(){
  $preText = get_option('counter4');
echo'<input type="text" name="counter4" placeholder="Copyright Text" value="'.$preText.'" />';
}


// Footer Copyright callbacks
function copyright_callback(){
  $preText = get_option('copyright');
echo'<input type="text" name="copyright" placeholder="First Counter Value" value="'.$preText.'" />';
}


// Media callbacks
function media1_callback(){
  $preText = get_option('media1');
echo'<input type="button" class="button button-secondary" value="Upload Picture" id="upload-button" />
<input type="hidden" name="media1" id="image-url" value="'.$preText.'" />';
}
